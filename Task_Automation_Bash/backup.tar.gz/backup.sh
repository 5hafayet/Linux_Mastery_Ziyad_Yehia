#!/bin/bash

tar -czf backup.tar.gz *
